# RPI-Flask-SQLite
Capturing real data (RPi/DHT22), saving them on a database (SQLite), creating graphs (Matplotlib) and present them on a web page(Flask). 
<br>
<br>
The complete project can be found on:
<p>
https://www.hackster.io/mjrobot/from-data-to-graph-a-web-jorney-with-flask-and-sqlite-4dba35
  </p>
<p>
and
</p>
https://www.instructables.com/id/From-Data-to-Graph-a-Web-Jorney-With-Flask-and-SQL/
<br>
<br>
<img src="https://github.com/Mjrovai/RPI-Flask-SQLite/blob/master/diagBlocos.png?raw=true">
